# PTS-Parking
## Python Modules Required
Please install Python3 and the following modules using the commands given below in the cmd terminal or Python IDE.

1.Pyautogui

2.PyGame

3.termcolor

### Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install the modules.

```bash
pip install pyautogui
```
```bash
pip install pygame
```
```bash
pip install termcolor
```

## License
[Apache 2.0](https://www.apache.org/licenses/LICENSE-2.0)