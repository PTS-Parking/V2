import pickle
import pyautogui
import time
import pygame

from datetime import date
from datetime import datetime
from termcolor import colored


def main_menu():
    global Usr_Act
    print("\n\n\n")
    print("==================================================================")
    print("Welcome to PTS Parking !!!\n")
    Usr_Act = int(input("""Choose an option from the following :(1/2/3/4)
1. Park your Vehicle
2. Exit the Parking Space
3. Admin Controls
4. Exit the Program
> """))
    time.sleep(0.5)


def vehicle_choice():
    print("------------------------------------------------------------------")
    vehicle_type = int(input("""Enter the vehicle type from the following : (1/2/3)
1. Car
2. Two Wheeler
3. LCV/Truck (> 4 Metric Tons)
> """))
    time.sleep(0.5)
    return vehicle_type


def park():
    try:
        log = open("prkg_log.dat", "rb+")
        logload = pickle.load(log)
        log.close()
    except FileNotFoundError:
        logload = []

    global park_spot_car
    global park_spot_bike
    global park_spot_truck

    vehicle_type = vehicle_choice()
    print("------------------------------------------------------------------")
    name = input("Enter your name : ")
    print("------------------------------------------------------------------")
    while True:
        number = input("Enter your mobile number : ")
        if len(number) != 10:
            print("Invalid phone number, it must be 10 digits long !\n")
            time.sleep(1)
            continue
        else:
            number = '+91' + number
            break
    Date = date.today().strftime("%B %d, %Y")
    Time = datetime.now().strftime("%H:%M:%S")
    vehicle = [name, number, Time, Date]
    print("------------------------------------------------------------------")

    if vehicle_type == 1:
        for i in range(len(park_spot_car)):
            if park_spot_car[i] is None:
                print("                   ", "You can park at", colored((str(i + 1) + 'C'), 'cyan', attrs=['reverse', 'blink']))
                print("     ", "Note, you parked on", Date, "at", Time)
                print("                       ", "Thank You !")
                park_spot_car[i] = vehicle
                slot = str(i + 1) + 'C'
                log_list = [Time, slot, name, number, "Parked"]
                logload.extend(log_list)
                log = open("prkg_log.dat", "wb")
                pickle.dump(logload, log)
                log.close()
                break
        else:
            print("Sorry all parking spots are occupied !")

    elif vehicle_type == 2:
        for i in range(len(park_spot_bike)):
            if park_spot_bike[i] is None:
                print("                   ", "You can park at", colored((str(i + 1) + 'B'), 'cyan', attrs=['reverse', 'blink']))
                print("     ", "Note, you parked on", Date, "at", Time)
                print("                       ", "Thank You !")
                park_spot_bike[i] = vehicle
                slot = str(i + 1) + 'B'
                log_list = [Time, slot, name, number, "Parked"]
                logload.extend(log_list)
                log = open("prkg_log.dat", "wb")
                pickle.dump(logload, log)
                log.close()
                break
        else:
            print("Sorry all parking spots are occupied !")

    elif vehicle_type == 3:
        for i in range(len(park_spot_truck)):
            if park_spot_truck[i] is None:
                print("                   ", "You can park at", colored((str(i + 1) + 'T'), 'cyan', attrs=['reverse', 'blink']))
                print("     ", "Note, you parked on", Date, "at", Time)
                print("                       ", "Thank You !")
                park_spot_truck[i] = vehicle
                slot = str(i + 1) + 'T'
                log_list = [Time, slot, name, number, "Parked"]
                logload.extend(log_list)
                log = open("prkg_log.dat", "wb")
                pickle.dump(logload, log)
                log.close()
                break
        else:
            print("Sorry all parking spots are occupied !")

    else:
        print("Invalid Vehicle type detected !")


def qr_code_load():
    pygame.init()
    screen = pygame.display.set_mode((500, 500))
    pygame.display.set_caption('QR Code')
    imp = pygame.image.load("GPay QR Code.jpg").convert()
    screen.blit(imp, (0, 0))
    pygame.display.flip()
    status = True
    while status:
        for i in pygame.event.get():
            if i.type == pygame.QUIT:
                status = False
    pygame.quit()


def exit_park():
    print("------------------------------------------------------------------")
    try:
        log = open("prkg_log.dat", "rb+")
        logload = pickle.load(log)
        log.close()
    except FileNotFoundError:
        logload = []

    global car_rate
    global bike_rate
    global truck_rate
    global prkg_spot

    prkg_spot = input("Enter parking spot : ")
    time.sleep(1)
    print("------------------------------------------------------------------")
    if prkg_spot[1] in ['c', 'C']:
        if park_spot_car[int(prkg_spot[0]) - 1] is None:
            print("No vehicle was parked at the given spot !")
        else:
            pay_method = int(input("""Enter the payment method from the following: (1/2)
1. Cash
2. UPI/PayTM/GPay/PhonePe
> """))
            print("------------------------------------------------------------------")
            time.sleep(1)
            Date = date.today().strftime("%B %d, %Y")
            Time = datetime.now().strftime("%H:%M:%S")
            hours = int(Time[0:2]) - int(park_spot_car[int(prkg_spot[0]) - 1][2][0:2])
            mins = int(Time[3:5]) - int(park_spot_car[int(prkg_spot[0]) - 1][2][3:5])
            spt_time = hours + (mins / 60)
            if spt_time <= 1:
                dtime = 1
            else:
                dtime = round(spt_time)
            amt = dtime * car_rate
            print("Note, you exited", prkg_spot, "on", Date, "at", Time)
            print("The total amount to be payed is :", colored(('₹' + str(amt)), 'cyan', attrs=['reverse', 'blink']))
            if pay_method == 2:
                print("\nPlease scan the QR Code that pops up to pay the amount !")
                time.sleep(3)
                qr_code_load()
                time.sleep(2)
            else:
                print("\nPlease pay the amount with cash !")
                time.sleep(3)
            print("------------------------------------------------------------------")
            print("Thank you for parking with us", park_spot_car[int(prkg_spot[0]) - 1][0], "!")
            log_list = [Time, prkg_spot, park_spot_car[int(prkg_spot[0]) - 1][0], park_spot_car[int(prkg_spot[0]) - 1][1], "Exit"]
            logload.extend(log_list)
            log = open("prkg_log.dat", "wb")
            pickle.dump(logload, log)
            log.close()
            park_spot_car[int(prkg_spot[0]) - 1] = None

    elif prkg_spot[1] in ['b', 'B']:
        if park_spot_bike[int(prkg_spot[0]) - 1] is None:
            print("No vehicle was parked at the given spot !")
        else:
            pay_method = int(input("""Enter the payment method from the following: (1/2)
1. Cash
2. UPI/PayTM/GPay/PhonePe
> """))
            print("------------------------------------------------------------------")
            time.sleep(1)
            Date = date.today().strftime("%B %d, %Y")
            Time = datetime.now().strftime("%H:%M:%S")
            hours = int(Time[0:2]) - int(park_spot_bike[int(prkg_spot[0]) - 1][2][0:2])
            mins = int(Time[3:5]) - int(park_spot_bike[int(prkg_spot[0]) - 1][2][3:5])
            spt_time = hours + (mins / 60)
            if spt_time <= 1:
                dtime = 1
            else:
                dtime = round(spt_time)
            amt = dtime * bike_rate
            print("Note, you exited", prkg_spot, "on", Date, "at", Time)
            print("The total amount to be payed is :", colored(('₹' + str(amt)), 'cyan', attrs=['reverse', 'blink']))
            if pay_method == 2:
                print("\nPlease scan the QR Code that pops up to pay the amount !")
                time.sleep(3)
                qr_code_load()
                time.sleep(2)
            else:
                print("\nPlease pay the amount with cash !")
                time.sleep(3)
            print("------------------------------------------------------------------")
            print("Thank you for parking with us", park_spot_bike[int(prkg_spot[0]) - 1][0], "!")
            log_list = [Time, prkg_spot, park_spot_bike[int(prkg_spot[0]) - 1][0], park_spot_bike[int(prkg_spot[0]) - 1][1], "Exit"]
            logload.extend(log_list)
            log = open("prkg_log.dat", "wb")
            pickle.dump(logload, log)
            log.close()
            park_spot_bike[int(prkg_spot[0]) - 1] = None
    elif prkg_spot[1] in ['t', 'T']:
        if park_spot_truck[int(prkg_spot[0]) - 1] is None:
            print("No vehicle was parked at the given spot !")
        else:
            pay_method = int(input("""Enter the payment method from the following: (1/2)
1. Cash
2. UPI/PayTM/GPay/PhonePe
> """))
            print("------------------------------------------------------------------")
            time.sleep(1)
            Date = date.today().strftime("%B %d, %Y")
            Time = datetime.now().strftime("%H:%M:%S")
            hours = int(Time[0:2]) - int(park_spot_truck[int(prkg_spot[0]) - 1][2][0:2])
            mins = int(Time[3:5]) - int(park_spot_truck[int(prkg_spot[0]) - 1][2][3:5])
            spt_time = hours + (mins / 60)
            if spt_time <= 1:
                dtime = 1
            else:
                dtime = round(spt_time)
            amt = dtime * truck_rate
            print("Note, you exited", prkg_spot, "on", Date, "at", Time)
            print("The total amount to be payed is :", colored(('₹' + str(amt)), 'cyan', attrs=['reverse', 'blink']))
            if pay_method == 2:
                print("\nPlease scan the QR Code that pops up to pay the amount !")
                time.sleep(3)
                qr_code_load()
                time.sleep(2)
            else:
                print("\nPlease pay the amount with cash !")
                time.sleep(3)
            print("------------------------------------------------------------------")
            print("Thank you for parking with us", park_spot_truck[int(prkg_spot[0]) - 1][0], "!")
            log_list = [Time, prkg_spot, park_spot_truck[int(prkg_spot[0]) - 1][0], park_spot_truck[int(prkg_spot[0]) - 1][1], "Exit"]
            logload.extend(log_list)
            log = open("prkg_log.dat", "wb")
            pickle.dump(logload, log)
            log.close()
            park_spot_truck[int(prkg_spot[0]) - 1] = None
    else:
        print("Invalid input detected !")


def password_check():
    global pswrd
    print("------------------------------------------------------------------")
    i = 3
    while i >= 0:
        print("Please enter the password in the secure window that pops up !")
        time.sleep(0.5)
        pwsrd_inp = pyautogui.password(text='Enter the Admin Password', title='Admin Access Check', default='', mask='*')
        if pwsrd_inp == pswrd:
            print("Admin access Granted !")
            time.sleep(1)
            return True
        elif pwsrd_inp == None:
            print("Operation Cancelled !")
            time.sleep(1)
            return
        else:
            print("Incorrect password,", i, " more attempts")
            time.sleep(0.25)
            i = i - 1
    return False


def admin_menu():
    global Adm_Act
    print("------------------------------------------------------------------")
    Adm_Act = int(input("""Choose an option from the following : (1/2/3/4/5)
1. View Parking Log
2. Change number of Parking Slots
3. Change Parking Rates
4. Change Admin Password
5. Back to menu
> """))
    time.sleep(1)


def log_view():
    print("--------------------------------------------------------------------------")
    print("Time \t\t Slot \t Name \t\t Number \t\t Action\n")
    log = open("prkg_log.dat", "rb")
    try:
        a = pickle.load(log)
        for i in range(len(a)):
            if (i + 1) % 5 == 0:
                print(a[i])
            else:
                print(a[i], " \t ", end="")
        log.close()
    except EOFError:
        log.close()
    print("--------------------------------------------------------------------------")
    print("End of log...")
    time.sleep(5)


def parking_slots():
    global park_spot_car
    global park_spot_bike
    global park_spot_truck
    veh_ch = vehicle_choice()
    print("------------------------------------------------------------------")
    while veh_ch == 1 or 2 or 3:
        if veh_ch == 1:
            prkg_length = len(park_spot_car)
            print("The total number of car parking spots = ", prkg_length)
            print("------------------------------------------------------------------")
            time.sleep(0.5)
            add_or_sub = input("Do you want to add or subtract parking spot(s) ? (+/-/Cancel) : ")
            time.sleep(1)
            if add_or_sub == '+':
                no_of_spots = int(input("Number of parking spots to add =  "))
                for i in range(no_of_spots):
                    park_spot_car.append(None)
                time.sleep(0.5)
                print(no_of_spots, "spot(s) added successfully !")
                time.sleep(1.5)
                break
            elif add_or_sub == '-':
                no_of_spots = int(input("Number of parking spots to subtract : "))
                for i in range(no_of_spots):
                    park_spot_car = park_spot_car[0:len(park_spot_car) - 1]
                time.sleep(0.5)
                print(no_of_spots, "spot(s) subtracted successfully !")
                time.sleep(1.5)
                break
            elif add_or_sub in ['cancel', 'Cancel', 'cncl', 'Cncl']:
                print("Operation cancelled !")
                time.sleep(1)
                break
            else:
                print("Invalid input detected !")
        if veh_ch == 2:
            prkg_length = len(park_spot_bike)
            print("The total number of bike parking spots = ", prkg_length)
            print("------------------------------------------------------------------")
            time.sleep(0.5)
            add_or_sub = input("Do you want to add or subtract parking spot(s) ? (+/-/Cancel) : ")
            time.sleep(1)
            if add_or_sub == '+':
                no_of_spots = int(input("Number of parking spots to add = "))
                for i in range(no_of_spots):
                    park_spot_bike.append(None)
                time.sleep(0.5)
                print(no_of_spots, "spot(s) added successfully !")
                time.sleep(1.5)
                break
            elif add_or_sub == '-':
                no_of_spots = int(input("Number of parking spots to subtract : "))
                for i in range(no_of_spots):
                    park_spot_bike = park_spot_bike[0:len(park_spot_bike) - 1]
                time.sleep(0.5)
                print(no_of_spots, "spot(s) subtracted successfully !")
                time.sleep(1.5)
                break
            elif add_or_sub in ['cancel', 'Cancel', 'cncl', 'Cncl']:
                print("Operation cancelled !")
                time.sleep(1)
                break
            else:
                print("Invalid input detected !")
        if veh_ch == 3:
            prkg_length = len(park_spot_truck)
            print("The total number of truck parking spots = ", prkg_length)
            print("------------------------------------------------------------------")
            time.sleep(0.5)
            add_or_sub = input("Do you want to add or subtract parking spot(s) ? (+/-/Cancel) : ")
            time.sleep(1)
            if add_or_sub == '+':
                no_of_spots = int(input("Number of parking spots to add = "))
                for i in range(no_of_spots):
                    park_spot_truck.append(None)
                time.sleep(0.5)
                print(no_of_spots, "spot(s) added successfully !")
                time.sleep(1.5)
                break
            elif add_or_sub == '-':
                no_of_spots = int(input("Number of parking spots to subtract : "))
                for i in range(no_of_spots):
                    park_spot_truck = park_spot_truck[0:len(park_spot_truck) - 1]
                time.sleep(0.5)
                print(no_of_spots, "spot(s) subtracted successfully !")
                time.sleep(1.5)
                break
            elif add_or_sub in ['cancel', 'Cancel', 'cncl', 'Cncl']:
                print("Operation cancelled !")
                time.sleep(1)
                break
            else:
                print("Invalid input detected !")
                time.sleep(0.25)


def change_rates():
    global car_rate
    global bike_rate
    global truck_rate
    veh_ch = vehicle_choice()
    print("------------------------------------------------------------------")
    if veh_ch == 1:
        car_rate = int(input("Enter the new rate (per hour) : "))
    elif veh_ch == 2:
        bike_rate = int(input("Enter new rate (per hour) : "))
    elif veh_ch == 3:
        truck_rate = int(input("Enter new rate (per hour) : "))
    time.sleep(1)
    print("Rate changed successfully !")
    time.sleep(1.5)


def change_password():
    global pswrd
    print("------------------------------------------------------------------")
    i = 3
    while i >= 0:
        print("Please enter the password in the secure window that pops up !")
        time.sleep(0.5)
        pwsrd_inp = pyautogui.password(text='Enter the old Admin Password', title='Change Admin Password', default='', mask='*')
        time.sleep(1.5)
        if pwsrd_inp == pswrd:
            pswrd = input("Enter the new password : ")
            time.sleep(1)
            print("Password changed successfully !")
            time.sleep(1.5)
            break
        elif pwsrd_inp == None:
            print("Operation Cancelled !")
            time.sleep(1)
            return
        else:
            print("Incorrect password,", i, " more attempts")
            time.sleep(0.25)
            i = i - 1


park_spot_car = [None, None, None, None]
park_spot_bike = [None, None, None, None, None, None, None, None]
park_spot_truck = [None, None]

car_rate = 30
bike_rate = 15
truck_rate = 50

pswrd = "PTS@123"

Usr_Act = 0

while Usr_Act != 4:
    main_menu()
    if Usr_Act == 1:
        park()
        time.sleep(5)
    elif Usr_Act == 2:
        exit_park()
        time.sleep(5)
    elif Usr_Act == 3:
        if password_check():
            Adm_Act = 0
            while Adm_Act != 5:
                admin_menu()
                if Adm_Act == 1:
                    log_view()
                elif Adm_Act == 2:
                    parking_slots()
                elif Adm_Act == 3:
                    change_rates()
                elif Adm_Act == 4:
                    change_password()
        else:
            print("-----------------------------------------------------------------------------------")
            print("You are temporarily locked out of the system due to suspicious activity !!!")
            print("-----------------------------------------------------------------------------------")
            time.sleep(2)
            exit()
    elif Usr_Act == 4:
        print("------------------------------------------------------------------")
        print("Thank you for using PTS Parking !")
        print("------------------------------------------------------------------")
        time.sleep(2)
        exit()
    else:
        print("------------------------------------------------------------------")
        print("Invalid input detected !!!")
        print("------------------------------------------------------------------")
        time.sleep(2)
